import os
import platform
import sqlite3

from flask import Flask, redirect, render_template, url_for

app = Flask(__name__)

DATA_DIR = os.environ.get("APP_DATA_DIR", ".")
DB_PATH = os.path.join(DATA_DIR, "hello.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS compteur ("
        "id INTEGER PRIMARY KEY, valeur INTEGER NOT NULL)"
    )
    conn.execute("INSERT OR IGNORE INTO compteur (id, valeur) VALUES (1, 0)")
    conn.commit()
    return conn


@app.route("/")
def index():
    conn = get_db()
    valeur = conn.execute("SELECT valeur FROM compteur WHERE id = 1").fetchone()[0]
    conn.close()
    return render_template(
        "index.html",
        valeur=valeur,
        python_version=platform.python_version(),
        sqlite_version=sqlite3.sqlite_version,
    )


@app.route("/plus", methods=["POST"])
def plus():
    conn = get_db()
    conn.execute("UPDATE compteur SET valeur = valeur + 1 WHERE id = 1")
    conn.commit()
    conn.close()
    return redirect(url_for("index"))
