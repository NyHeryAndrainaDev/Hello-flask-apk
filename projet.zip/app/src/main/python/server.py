"""Lanceur Flask pour la coquille APK.

Convention : le projet de l'utilisateur est copié dans un vrai dossier
(project_dir) et doit contenir un fichier app.py avec une variable `app`
(l'objet Flask). Les données persistantes (SQLite...) vont dans data_dir,
défini aussi dans la variable d'environnement APP_DATA_DIR.
"""
import importlib
import os
import sys
import threading

from werkzeug.serving import make_server

_lock = threading.Lock()
_server = None


def start(project_dir, data_dir, port=5000):
    global _server
    with _lock:
        if _server is not None:
            return port

        os.makedirs(data_dir, exist_ok=True)
        os.environ["APP_DATA_DIR"] = data_dir
        os.chdir(data_dir)

        if project_dir not in sys.path:
            sys.path.insert(0, project_dir)

        module = importlib.import_module("app")
        flask_app = getattr(module, "app")

        _server = make_server("127.0.0.1", int(port), flask_app, threaded=True)
        threading.Thread(target=_server.serve_forever, daemon=True).start()
        return port
