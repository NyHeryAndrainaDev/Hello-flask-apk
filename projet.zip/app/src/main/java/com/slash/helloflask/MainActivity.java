package com.slash.helloflask;

import android.app.Activity;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int PORT = 5000;
    private static boolean serverReady = false;

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());

        if (serverReady) {
            webView.loadUrl("http://127.0.0.1:" + PORT + "/");
            return;
        }

        showHtml("<h3 style='font-family:sans-serif;text-align:center;margin-top:30%'>D\u00e9marrage...</h3>");

        final File projectDir = new File(getFilesDir(), "project");
        final File dataDir = new File(getFilesDir(), "data");

        new Thread(() -> {
            try {
                // 1) copie du projet (assets/project) vers un vrai dossier
                deleteRecursive(projectDir);
                copyAssets("project", projectDir);
                dataDir.mkdirs();

                // 2) d\u00e9marrage de Python + Flask
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(this));
                }
                Python.getInstance().getModule("server").callAttr(
                        "start", projectDir.getAbsolutePath(), dataDir.getAbsolutePath(), PORT);
                serverReady = true;

                // 3) affichage dans la WebView
                runOnUiThread(() -> webView.loadUrl("http://127.0.0.1:" + PORT + "/"));
            } catch (Exception e) {
                final String msg = TextUtils.htmlEncode(e.toString());
                runOnUiThread(() -> showHtml(
                        "<h3 style='font-family:sans-serif'>Erreur au d\u00e9marrage</h3>"
                                + "<pre style='white-space:pre-wrap;font-size:12px'>" + msg + "</pre>"));
            }
        }).start();
    }

    private void showHtml(String body) {
        webView.loadDataWithBaseURL(null, "<html><body>" + body + "</body></html>",
                "text/html", "UTF-8", null);
    }

    private void copyAssets(String assetPath, File dest) throws IOException {
        AssetManager am = getAssets();
        String[] children = am.list(assetPath);
        if (children != null && children.length > 0) {
            dest.mkdirs();
            for (String c : children) {
                copyAssets(assetPath + "/" + c, new File(dest, c));
            }
        } else {
            File parent = dest.getParentFile();
            if (parent != null) parent.mkdirs();
            try (InputStream in = am.open(assetPath);
                 OutputStream out = new FileOutputStream(dest)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
            }
        }
    }

    private static void deleteRecursive(File f) {
        if (!f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) deleteRecursive(k);
        }
        f.delete();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
